take note: in 1.7.x you must add an init unit in your uses clause before
and other units.

Example: see pwinit.pas and pwinitall.pas in ../../main/ folder
