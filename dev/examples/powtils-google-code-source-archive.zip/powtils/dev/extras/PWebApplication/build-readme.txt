Build.exe or build.linux etc. is a system built by Lars (L505) that builds
the powtils examples.

Build.exe or Build.linux/Build.bsd will build Jorges template demos in one shot

It is powered by the pwbuildutil.pas unit.

For more info, see the readme in the other main examples/ folder 