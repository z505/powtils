function writestr(x);
{
document.write(x);
}

function writestrln(x);
{
document.write(x);
}

function writeint(x);
{
document.write(x);
}

function writeintln(x);
{
document.write(x);
}

function test();
{
var c;
var b;
var a;
while (b && c || !b)
for (c=1; c==100; c++)
{
writeint(c);
b = (c == 10);
};
if (b == c)
{
a = (a + 1);
while (!(a == 10))
{
a = (a + 1);
};
};
else
{
a = (a - 1);
while (!(a == 0))
{
a = (a - 1);
};
};
;
}

function test2();
{
return (1);
}


